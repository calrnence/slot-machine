import numpy as np

def main():
    status = True
    while status:
        choice = menu()
        if choice == 1:
            slots = wheels()
            win, winning_row = winloss(slots)
        elif choice == 3:
            status = False

# create user interface for user to select what they want to do
# error check for validity of input
def menu():
    print("MENU")
    print("1.SPIN")
    print("2.CASH OUT")
    print("3.QUIT")
    choice = int(input("Enter your choice: "))
    if choice < 1 or choice > 3:
        choice = int(input("Enter a valid choice: "))
        
    return choice

# generate and return random number
def spin():
    number = np.random.randint(0,9)
    return number

# create board for user to see results of spin
# print board
# return board
def wheels():
    symbols = ['SEVEN', 'BANANA', 'WATERMELON', 'BELL', 'BAR', 'LEMON', 'ORANGE', 'GRAPE', 'CHERRY']
    board = [['','',''],
             ['','',''],
             ['','','']]
    for row in board:
        i=0
        for j in row:
            row[i] = symbols[spin()]
            i+=1
    print()
    print("Spinning...")
    for j in board:
        for k in j:
            print(k, end='   ')
        print()
    return board

# check for winning rows in the board
# if win is true for one row
def winloss(board):
    win = False
    winning_row = []
    for row in board:
        if row[0] == row[1] == row[2]:
            win = True
            winning_row.append(row)
    if win == True:
        print()
        print("Congratulations! We have a winner!")
    else:
        print()
        print("Please try again!")
        
    return win, winning_row

def points(rows):
    system = {'SEVEN':7, 'BANANA':1, 'WATERMELON':3, 'BELL':10, 'BAR':5, 'LEMON':3, 'ORANGE':1, 'GRAPE':1, 'CHERRY':1}
    total = 0
    for row in rows:
        for i in row:
            point = system[i]
            total = total+point
    return total

main()
        
    


