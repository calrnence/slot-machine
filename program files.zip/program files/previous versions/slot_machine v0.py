import numpy as np

symbols = ['SEVEN', 'BANANA', 'WATERMELON', 'BELL', 'BAR', 'LEMON', 'ORANGE', 'GRAPE', 'CHERRY']

def main():
    results = wheels()
    print("Spinning...")
    print("%s\n%s\n%s" % (results[0], results[1], results[2]))
    winLoss(results[0], results[1], results[2])

def spin():
    spinning = np.random.randint(0,9)
    return symbols[spinning]

def wheels():
    row1 = []
    row2 = []
    row3 = []
    for i in range(0,3):
        row1.append(spin())
        row2.append(spin())
        row3.append(spin())

    return row1, row2, row3

def winLoss(row1,row2,row3):
    if row1[0] == row1[1] == row1[2]:
        print("We have a winner!")
        win = True
    elif row2[0] == row2[1] == row2[2]:
        print("We have a winner!")
        win = True
    elif row3[0] == row3[1] == row3[2]:
        print("We have a winner!")
        win = True
    else:
        print("Unfortunately, you are not a winner.")
        win = False
    return win
    
main()
    
    


