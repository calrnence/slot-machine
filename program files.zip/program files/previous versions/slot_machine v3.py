import random
import time

def main():
    status = True
    account, balance = loadacc()
    while status:
        choice = menu(balance)
        if choice == 1:
            bet, balance = betting(balance)
        if choice == 1 and bet != 0:
            slots = wheels()
            balance = winnings(bet,slots,balance)
        elif choice == 2:
            balance = bank(balance)
        elif choice == 3:
            saveacc(account,balance)
            status = False
        
# create user interface for user to select what they want to do
# error check for validity of input, expects an integer
def menu(balance):
    try:
        print()
        print("MENU")
        print("----------")
        print("1.SPIN")
        print("2.ACCOUNT")
        print("3.QUIT")
        print("Your account balance is $%.2f" % balance)
        choice = int(input("Enter your choice: "))
        while choice < 1 or choice > 3:
            choice = int(input("Enter a valid choice: "))
        return choice
    except ValueError:
        print("Invalid input provided. Returning to home screen...")
        

# get bet amount from user
# if betting more than balance, reprompt user
def betting(balance):
    try:
        bet = float(input("Enter your bet or '0' to go back: "))
        while bet > balance or bet < 0: 
            bet = float(input("Enter a valid bet or enter '0' to go back: "))
        balance = balance - bet
        return bet, balance
    except ValueError or TypeError:
        print("Invalid input provided. Returning to home screen...")
        return 0, balance

# generate and return random number
def spin(symbols):
    chances = [7,20,10,1,12,15,10,15,10]
    # chances = [0,0,0,1,1,0,0,0,0] testing
    symbol = random.choices(symbols, chances) # returns list
    return symbol[0]

# create board for user to see results of spin
# print board
# return board
def wheels():
    symbols = ['SEVEN', 'BANANA', 'WATERMELON', 'BELL', 'BAR', 'LEMON', 'ORANGE', 'GRAPE', 'CHERRY']
    board = [['','',''],
             ['','',''],
             ['','','']]
    for row in board:
        for i in range(len(row)):
            row[i] = spin(symbols)
    printboard(board)
    return board

# print board function
def printboard(board):
    print()
    print('Spinning...')
    print()
    time.sleep(1)
    for i in board:
        print('{:<15}{:<15}{:<15}'.format(i[0],i[1],i[2]))

# check for winning rows in the board
# if win is true for one row calculate cash multiplier for the row
# sum up the multipliers
def winloss(board):
    time.sleep(1)
    win = False
    winning_row = []
    for row in board:
        if len(set(row)) == 1:
            win = True
            winning_row.append(row)
    if win == True:
        multiplier = points(winning_row)
        print()
        print("Congratulations! We have a winner!")
        
    else:
        multiplier = 0
        print()
        print("Please try again!")
    return win, multiplier

# calculate points from winning symbols 
# returns sum of points
def points(rows):
    system = {'SEVEN':7, 'BANANA':1, 'WATERMELON':3, 'BELL':10, 'BAR':5, 'LEMON':3, 'ORANGE':3, 'GRAPE':3, 'CHERRY':1}
    total = 0
    for row in rows:
        for i in row:
            point = system[i]
            total = total+point
    return total

# calculates winnings
def winnings(bet,board,balance):
    win, multiplier = winloss(board)
    if win == True:
        win = False
        winning = bet*multiplier
        balance = balance + winning
        print("You have won $%.2f!" % winning)
        print("It has been automatically added to your account.")
    return balance

# creates "bank" for user to store and withdraw money from while spinning
# ask user for withdrawal or deposit or return
def bank(total):
    try:
        choice = str(input("Would you like to make a deposit or a withdrawal? Enter 'DEPOSIT' or 'WITHDRAWAL' or 'RETURN': ")).lower()
        while choice not in {'deposit','withdrawal','return'}:
            choice = str(input("Please make a valid choice: 'DEPOSIT' or 'WITHDRAWAL' or 'RETURN': ")).lower()
        
        if choice == 'withdrawal':
            withdraw = float(input("How much would you like to withdraw?: "))
            withdraw = round(withdraw,2)
            while withdraw > total or withdraw < 0:
                withdraw = float(input("Enter a valid withdrawal amount: "))
            total = total - withdraw
            print("Your new total balance is $%.2f" % round(total,2))
        
        elif choice == 'deposit':
            deposit = float(input("How much would you like to deposit?: "))
            deposit = round(deposit,2)
            total = total + deposit
            print("Your new total balance is $%.2f!" % round(total,2))
        
        elif choice == 'return':
            pass
        return total
    except ValueError:
        print("Invalid input provided. Returning to home screen...")
        return total

# reads account text file to procure saved accounts and their balances
# in the case that an account does not exist for whatever reason,
# essentially creates new account with number=1 and balance of 0.00
def loadacc():
    file = open('accounts.txt', 'r', newline='') 
    lines = file.readlines()
    file.close()
    try:
        for line in lines:
            if line != lines[0]:
                line = line.rstrip()
                line = line.split(',')
                info = {'ACCOUNT':line[0], 'BALANCE':float(line[1])}
        return info['ACCOUNT'], info['BALANCE']
    except:
        return 1, 0.00   

# saves current account and corresponding balance to a text file so it can
# be accessed later
def saveacc(account,balance):
    labels = ('ACCOUNT,BALANCE')
    file = open('accounts.txt', 'w', newline='')
    file.write(labels+'\n')
    file.write('%s,%.2f' % (account, balance))
    file.close()
main()
        
    


