import random
import time
import matplotlib.pyplot as plt

def main():
    status = True
    account, balance = loadacc()
    while status:
        choice = menu(balance)
        if choice == 1:
            bet, balance = betting(balance)
        if choice == 1 and bet != 0:
            slots = wheels()
            balance = winnings(bet,slots,balance)
            time.sleep(1)
        elif choice == 2:
            balance = bank(balance)
        elif choice == 3:
            saveacc(account,balance)
            status = False
        
# create user interface for user to select what they want to do
# error check for validity of input, expects an integer
def menu(balance):
    try:
        global box
        box = dict(facecolor='white',edgecolor='black',boxstyle='round,pad=0.5', lw=1.5)
        axs = menuscreen(balance)
        axs.text(0.5,0.2, '1. ITS GAMBLING TIME\n\n2. ACCOUNT\n\n3. QUIT', ha='center',
                 bbox=box)
        plt.show()
        choice = int(input("Enter your choice: "))
        while choice < 1 or choice > 3:
            choice = int(input("Enter a valid choice: "))
    except ValueError:
        print("Invalid input provided. Returning to home screen...")
        return ''
    return choice

# create matplotlib figure that makes the basic menu screen that stays static
# throughout the game
def menuscreen(balance):
    plt.figure(facecolor=(0.61, 0.11 ,0.19))
    axs = plt.gca()
    axs.axis('off')
    axs.text(0.5,0.8,'REALLY GOOD SLOT MACHINE', fontsize='xx-large', fontweight='bold', ha='center',
             bbox=dict(facecolor='w',edgecolor='black',boxstyle='round,pad=1', lw=3))
    axs.text(0.5,0.575,('ACCOUNT BALANCE: $%.2f' % balance), fontsize='x-large', ha='center',
             bbox=dict(facecolor='gold',edgecolor='black',boxstyle='round', lw=1.5))
    return axs

# create matplotlib figure that adds onto main menu screen
# get bet amount from user
# if betting more than balance, reprompt user
def betting(balance):
    try:
        axs = menuscreen(balance)
        axs.text(0.5,0.35, "ENTER A BET OR ENTER '0' TO GO BACK:", ha='center',
                 bbox=dict(facecolor='white',edgecolor='black',boxstyle='round,pad=0.5', lw=1.5))
        plt.show()
        bet = float(input("Enter a bet or enter '0' to go back: "))
        while bet > balance or bet < 0: 
            bet = float(input("Enter a valid bet or enter '0' to go back: "))
        return bet, balance
    except ValueError or TypeError:
        print("Invalid input provided. Returning to home screen...")
        return 0, balance


# generate the random numbers and organize into 3x3 grid
# create a graphic for user to see results of spin
# return board
def wheels():
    symbols = ['SEVEN', 'BANANA', 'WATERMELON', 'BELL', 'BAR', 'LEMON', 'ORANGE', 'GRAPE', 'CHERRY']
    chances = [7,20,10,1,12,15,10,15,10]
    # chances = [0,0,0,1,1,0,0,0,0] testing
    board = [['','',''],
             ['','',''],
             ['','','']]
    for row in board:
        for i in range(len(row)):
            row[i] = random.choices(symbols, chances)[0] # returns list
    print()
    print("Spinning..")
    print()
    time.sleep(1)
    makeboard(board)
    return board

# creates matplotlib figure using input symbols
def makeboard(board):
    images = imgload()
    fig, axs = plt.subplots(3,3, sharex=True, sharey=True)
    fig.set_facecolor((0.61, 0.11 ,0.19))
    plt.subplots_adjust(wspace=-0.5)
    for i in range(len(board)):
        for j in range(3):
            icon = images[board[i][j]]
            axs[i,j].imshow(icon)
            axs[i,j].axis('on')
            axs[i,j].set_xticks([])   
            axs[i,j].set_yticks([])
            for axis in ['top','bottom','left','right']:
                axs[i,j].spines[axis].set_linewidth(4)
            
# check for winning rows in the board
# if win is true for one row calculate cash multiplier for the row
# sum up the multipliers
def winloss(board):
    makeboard(board)
    win = False
    winning_row = []
    for row in board:
        if len(set(row)) == 1:
            win = True
            winning_row.append(row)
    if win == True:
        multiplier = points(winning_row)
        plt.gcf().text(0.5,0.5, "WINNER!", fontsize='x-large', fontweight='bold', ha='center',
                 bbox=dict(facecolor='gold',edgecolor='black', boxstyle='round,pad=0.5', lw=1.5))
    else:
        multiplier = 0
        plt.gcf().text(0.5,0.5, "TRY AGAIN NEXT TIME!", fontsize='x-large', fontweight='bold', ha='center',
                 bbox=dict(facecolor='gold',edgecolor='black',boxstyle='round,pad=0.5', lw=1.5))
    time.sleep(1)    
    plt.show()
    return win, multiplier

# calculate points from winning symbols 
# returns sum of points
def points(rows):
    system = {'SEVEN':7, 'BANANA':1, 'WATERMELON':3, 'BELL':10, 'BAR':5, 'LEMON':3, 'ORANGE':3, 'GRAPE':3, 'CHERRY':1}
    total = 0
    for row in rows:
        for i in row:
            point = system[i]
            total = total+point
    return total

# calculates winnings
def winnings(bet,board,balance):
    win, multiplier = winloss(board)
    if win == True:
        win = False
        winning = bet*multiplier
        balance = balance + winning
        print("You have won $%.2f!" % winning)
        print("It has been automatically added to your account.")
    return balance

# creates "bank" for user to store and withdraw money from while spinning
# ask user for withdrawal or deposit or return
def bank(total):
    try:
        axs = menuscreen(total)
        axs.text(0.5,0.1, 'WELCOME TO THE BANK.\n\n1. DEPOSIT\n\n2. WITHDRAWAL\n\n3. RETURN', ha='center',
                 bbox=box)
        plt.show()
        choice = str(input("Enter 'DEPOSIT' or 'WITHDRAWAL' or 'RETURN': ")).lower()
        while choice not in {'deposit','withdrawal','return','1','2','3'}:
            choice = str(input("Please make a valid choice: 'DEPOSIT' or 'WITHDRAWAL' or 'RETURN': ")).lower()
        if choice in {'deposit', '1'}:
            axs = menuscreen(total)
            axs.text(0.5,0.4, 'DEPOSIT AMOUNT: ', ha='center',
                     bbox=box)
            plt.show()
            deposit = float(input("How much would you like to deposit?: "))
            deposit = round(deposit,2)
            total = total + deposit
            
        elif choice in {'withdraw', '2'}:
            axs = menuscreen(total)
            axs.text(0.5,0.4, 'WITHDRAWAL AMOUNT: ', ha='center',
                     bbox=box)
            plt.show()
            withdraw = float(input("How much would you like to withdraw?: "))
            withdraw = round(withdraw,2)
            while withdraw > total or withdraw < 0:
                withdraw = float(input("Enter a valid withdrawal amount: "))
            total = total - withdraw
        
        elif choice in {'return', '3'}:
            pass
        
        print()
        print("Your new total balance is $%.2f" % round(total,2))
        
        return total
    
    except ValueError:
        print("Invalid input provided. Returning to home screen...")
        return total

# reads account text file to procure saved accounts and their balances
# in the case that an account does not exist for whatever reason,
# essentially creates new account with number=1 and balance of 0.00
def loadacc():
    file = open('accounts.txt', 'r', newline='') 
    lines = file.readlines()
    file.close()
    try:
        for line in lines:
            if line != lines[0]:
                line = line.rstrip()
                line = line.split(',')
                info = {'ACCOUNT':line[0], 'BALANCE':float(line[1])}
        return info['ACCOUNT'], info['BALANCE']
    except:
        return 1, 0.00   

# saves current account and corresponding balance to a text file so it can
# be accessed later
def saveacc(account,balance):
    labels = ('ACCOUNT,BALANCE')
    file = open('accounts.txt', 'w', newline='')
    file.write(labels+'\n')
    file.write('%s,%.2f' % (account, balance))
    file.close()

# gets graphics from pre existing png files and turns into an array
# return array containing color values of each image
def imgload():
    names = ['SEVEN', 'BANANA', 'WATERMELON', 'BELL', 'BAR', 'LEMON', 'ORANGE', 'GRAPE', 'CHERRY']
    icons = {}
    for i in range(len(names)):
        image = plt.imread(names[i].lower()+'.png')
        icons.update({names[i]:image})
    return icons


main()
        

