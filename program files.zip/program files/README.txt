Written solely by Clarence Hua

coded on python 3.8.10

libraries used:
matplotlib.pyplot
time 
random


follow instructions in console/image to play

must have ALL image files and accounts.txt for code to work properly

betting deducts from current balance, if balance = 0.00, you must deposit more in order to spin

feel free to make a copy and edit the code in order to spin until you win
